# JARVIS — Patission 155 (v0.3 UI refresh)

This package refreshes the local demo interface to a dark charcoal / warm orange repair-shop dashboard inspired by the reference screenshot.

## Run it
1. Extract the ZIP to a normal folder (do not run it from inside the ZIP preview).
2. Open `index.html` in Chrome or Edge.
3. Use the language selector for English, Greek, or Arabic.
4. Add repairs, customers, sales, and stock using the dashboard actions.

## Important limitations
- This is still a browser-local prototype. Data is stored in that browser's localStorage on that computer.
- The sample repair/customer/stock records are demonstration data. Replace them with real shop records only after the database-backed version is connected.
- It is not yet connected to the FastAPI/Supabase backend from v0.2.
- No real AI assistant, WhatsApp messaging, payment processing, invoicing, or cloud sync is enabled yet.
- Google Fonts are optional; the page uses system sans-serif fallbacks if offline.

The ZIP includes `index.html`, `styles.css`, and `app.js`.
